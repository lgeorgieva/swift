package com.company;

import java.util.Scanner;

/**
 * Created by ASUS on 21.10.2016 г..
 */
public class Task5_SwapVariables {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        int firstValue = scn.nextInt();
        int secondValue = scn.nextInt();
        System.out.print(secondValue+" ");
        System.out.print(firstValue);
    }
}

