package com.company;

/**
 * Created by ASUS on 21.10.2016 г..
 */
public class Task3_CalculateExpression {
    public static void main(String[] args) {
        double a = ( 3291 + 88581 ) / 14;
        double b =  ( 1116 % 171 ) * 5;
        double c =  312 / ( 4 + 18 );
        double result = a + b - c;

        System.out.println(result);

    }
}
